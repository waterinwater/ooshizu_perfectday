﻿##翻页符号
image PageBreak_anim:
    "PageBreak_a.webp"
    zoom 0.8
    crop (0, 0, 48, 48)
    pause 0.08
    crop (48, 0, 48, 48) 
    pause 0.08
    crop (96, 0, 48, 48)
    pause 0.08
    crop (144, 0, 48, 48) 
    pause 0.08
    crop (192, 0, 48, 48)
    pause 0.08
    crop (240, 0, 48, 48)
    pause 0.08
    crop (288, 0, 48, 48)
    pause 0.08
    crop (336, 0, 48, 48)
    pause 0.08
    crop (384, 0, 48, 48)
    pause 0.08
    crop (432, 0, 48, 48)
    pause 0.08
    crop (480, 0, 48, 48)
    pause 0.08
    crop (528, 0, 48, 48) 
    pause 0.08
    crop (576, 0, 48, 248) 
    pause 0.08
    crop (624, 0, 48, 48)
    pause 0.08
    crop (672, 0, 48, 48) 
    pause 0.08
    crop (720, 0, 48, 48) 
    pause 0.08
    repeat
##基础设置
default preferences.text_cps = 30

init -1 python:
    # 1. 定义两个基础矩阵
    matrix_normal = TintMatrix("#ffffff")
    matrix_dark = TintMatrix("#999999")

    # 2. 核心：让指定的 tag 在特定时间内变亮或变暗
    def set_character_brightness(tag, talker_speaker, speaker):
        # 判定这个 tag 是不是当前说话的人（或其差分部件）
        # 比如 speaker 是 "oosaki"
        # 那么 "oosaki", "oosakibody", "oosakihand" 都会匹配成功
        is_talker = False
        if speaker:
            if tag == speaker or tag.startswith(speaker):
                is_talker = True
            # 如果你的底层叫 oosakibody，说话人标签叫 oosaki，用 startswith 也能完美兼容
            elif tag.startswith(speaker):
                is_talker = True

        # 获取该图层的当前 transform 状态
        # 我们直接对其 matrixcolor 属性进行渐变赋值
        atl = renpy.get_at_list(tag)
        
        if is_talker:
            # 说话者：0.15秒变亮
            renpy.show(tag, at_list=[Transform(matrixcolor=matrix_normal, delay=0.15)])
        else:
            # 听众：如果是我们需要控制的这些角色，0.15秒变暗
            if tag.startswith(("oosaki", "shizuma", "kado")):
                renpy.show(tag, at_list=[Transform(matrixcolor=matrix_dark, delay=0.15)])

    # 3. 全员通用的亮暗控制函数
    def global_talk_callback(event, interact=True, **kwargs):
        if not interact:
            return

        if event == "begin":
            # 拿到当前真正说话的角色 image 标签（比如 "oosaki"）
            speaker = kwargs.get("image", None) or renpy.get_say_image_tag()
            
            # 获取当前舞台上所有正在显示的 tag（包含所有差分部件的主 tag）
            showing_tags = renpy.get_showing_tags()

            for tag in showing_tags:
                set_character_brightness(tag, speaker, speaker)

    # 4. 将函数注册到 Ren'Py 的 say_callback 中
    config.character_callback = global_talk_callback

layeredimage oosaki:
    always:
        "images/fg/oosakibody_normal.webp"

    group face:
        attribute default_face default:
            Null()
        attribute smile:
            "images/fg/oosaki_smile.webp"
        attribute surprise:
            "images/fg/oosaki_surprise.webp"
        attribute sleep:
            "images/fg/oosaki_sleep.webp" 
        
    group moreface:
        attribute default_red default:
            Null()
        attribute red:
            "images/fg/oosaki_idk.webp"
        attribute water:
            "images/fg/oosakiplus_water.webp"

    group blood:
        attribute default_blood default:
            Null()
        attribute blood1:
            "images/fg/oosaki_blood1.webp"
        attribute blood2:
            "images/fg/oosaki_blood2.webp"
        attribute blood3:
            "images/fg/oosaki_blood3.webp"
        attribute black:
            "images/fg/oosaki_black.webp"


# 把所有部件打包成一个统一的标签：shizuma
layeredimage shizuma:
    # 【第一层：身体/姿势组】位于最底层
    group body:
        attribute normal_body default:
            "images/fg/shizuma_normal_body.webp"  # 正常身体
        attribute with_hand:
            "images/fg/shizuma_with_hand.webp"    # 抱胸身体（举例）
    # 【第二层：表情组】叠在身体上面
    group face:
        attribute default_face default:
            Null()
        attribute happy:
            "images/fg/shizuma_happy.webp"
        attribute bigsmile:
            "images/fg/shizuma_bigsmile.webp"
        attribute stare:
            "images/fg/shizuma_stare.webp"
        attribute think:
            "images/fg/shizuma_think.webp"
        attribute surprise:
            "images/fg/shizuma_surprise.webp"
        attribute wink1:
            "images/fg/shizuma_wink.webp"
        attribute wink2:
            "images/fg/shizuma_wink2.webp"
    group hand:
        attribute default_hand default:
            Null()
        attribute juice:
            "images/fg/shizuma_juice.webp"
        attribute eat:
            "images/fg/shizumahand_eat.webp"
    group moreface:
        attribute default_red default:
            Null()
        attribute red:
            "images/fg/shizuma_idk.webp"
        attribute water:
            "images/fg/shizuma_water.webp"
        

    # 【第三层：饰品/眼镜组】叠在表情上面（最顶层）
    group glasses:
        attribute default_glasses default:
            Null()
        attribute glasses1:
            "images/fg/shizuma_glasses1.webp"
        attribute glasses2:
            "images/fg/shizumaplus_glasses2.webp"

    group color:
        attribute default_color default:
            Null()
        attribute green:
            "images/fg/shizuma_green.webp"
        attribute black:
            "images/fg/shizuma_black.webp"


'''
# 确保你的图片在 images 文件夹里的名字和后面备注的一致
layeredimage shizuma:

    # 【第一层：身体组】
    group body:
        # 对应文件：images/shizuma_normal_body.webp (或者按你原名，看下方微调)
        attribute normal_body default 
        attribute with_hand

    # 【第二层：表情组】
    group face:
        attribute default_face default:
            Null()  

    # 【第三层：手部组件】
    group hand:
        attribute default_hand default:
            Null()
        attribute juice

    # 【第四层：眼镜组】
    group glasses:
        attribute no_glasses default:
            Null()  
        attribute glasses1'''


##角色
define narrator = Character(None,ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled")
define a = Character("大崎",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled", callback=global_talk_callback, image="oosaki")
define b = Character("清",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled",callback=global_talk_callback, image="shizuma")
define c = Character("新木场",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled")
define p1 = Character("老板娘",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled")
define p2 = Character("报童",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled")
define p3 = Character("老者",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled",callback=global_talk_callback, image="kado")
define g = Character("绿衣服的男人",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled",callback=global_talk_callback, image="shizuma")
define h = Character("加藤",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled",callback=global_talk_callback, image="kado")
define i = Character("女性的声音",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled")
define j1 = Character("选手一",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled")
define j2 = Character("选手二",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled")
define j3 = Character("山田&横田",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled")
define j4 = Character("主持人",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled")
define j5 = Character("护士",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled")
define j6 = Character("接待员",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled")
define m4 = Character("佐清",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled",callback=global_talk_callback, image="shizuma")
define m2 = Character("？？？",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled",callback=global_talk_callback, image="shizuma")
define m3 = Character("陌生的女性",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled")
define q = Character("哥哥",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled")
define r= Character("广播",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled",callback=global_talk_callback)
define t= Character("警察",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled")
define s1= Character("犬神智",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled")
define s2= Character("犬神智的儿子",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled")
define s3= Character("台场夫人",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled")
define s4= Character("大江",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled")
define s5= Character("不认识的上班族",ctc="PageBreak_anim",ctc_pause="PageBreak_anim",ctc_position="nestled")

##效果
define fast_push = PushMove(0.15, "pushright")
define fast_push_left = PushMove(0.15, "pushleft")
define fast_push_down = PushMove(0.15, "pushdown")
define fast_push_up = PushMove(0.15, "pushup")
define slow_pixellate = Pixellate(2.0, 5)

transform oosaki_left:
    xalign -0.05     # 靠左站
    yalign 1.0      # 脚踩底
    zoom 1.5       # 💥 强行在这里放大 2.0 倍！

transform oosaki_middle:
    xalign 0.5     # 靠左站
    yalign 1.0      # 脚踩底
    zoom 1.5       # 💥 强行在这里放大 2.0 倍！

transform shizuma_right:
    xalign 1.1     # 靠左站
    yalign 1.0      # 脚踩底
    zoom 0.9       # 💥 强行在这里放大 2.0 倍！

transform shizuma_middle:
    xalign 0.58
    yalign 1.0      # 脚踩底
    zoom 0.9       # 💥 强行在这里放大 2.0 倍！

transform shizuma_left:
    xalign 0
    yalign 1.0      # 脚踩底
    zoom 0.9       # 💥 强行在这里放大 2.0 倍！

transform kado_middle:
    xalign 0.5
    yalign 1.0
    zoom 1.5

transform kado_left:
    xalign -0.1
    yalign 1.0
    zoom 1.5

transform spot(x=0.5, z=1.5, y=1.0):
    xalign x
    yalign y
    zoom z

transform fall_down(t=0.4):
    # yanchor 1.0 确保立绘以脚底为锚点
    yanchor 1.0 
    
    # linear 0.05 yoffset -20  # 选项：如果你想让角色摔倒前先稍微“往上弹一下”制造反冲，可以解开这两行
    # easein 0.1 yoffset 10
    
    # 🎯 核心：easein 会让角色越掉越快，符合重力加速度
    # yoffset 1500 确保立绘被猛地向下拽出屏幕（1500像素足够完全离开 1080p 屏幕）
    easein t yoffset 1500

# 🎯 定义一个精神污染扭曲滤镜
transform background_madness:
    zoom 1.1
    anchor (0.5, 0.5)
    pos (0.5, 0.5)
    
    block:
        # 🎯 终极修正：把错字 xscale/yscale 改成真正的 xzoom/yzoom！
        easein_quad 1.5:
            xzoom 1.08
            yzoom 0.92
            rotate 2
            
        easeout_quad 1.5:
            xzoom 0.92
            yzoom 1.08
            rotate -2
            
        easein_quad 1.5:
            xzoom 0.95
            yzoom 0.95
            rotate -1
            
        easeout_quad 1.5:
            xzoom 1.05
            yzoom 1.05
            rotate 1
            
        repeat

transform background_madness2:
    # 🎯 准备工作：
    # 因为要颠倒，zoom 必须放大到 1.5 倍左右，否则旋转时四角会露出大面积黑边！
    zoom 1.5
    anchor (0.5, 0.5)
    pos (0.5, 0.5)
    
    # ==========================================
    # 阶段一：世界崩塌！画面开始旋转 180 度变成倒的
    # ==========================================
    # easein_cubic 可以让旋转有一个从慢到快的加速感，更显惊悚
    # 这里用 3.0 秒转完一圈（你可以自己改时间），最终停在 180 度（即完全倒过来）
    easein_cubic 1.0 rotate 180
    
    # ==========================================
    # 阶段二：定格完毕，开始以倒过来的样式永久扭曲
    # ==========================================
    # 我们用 block 和 repeat 让接下来的蠕动无限循环
    # ⚠️ 注意：因为现在的初始基础角度是 180 度，所以微调扭曲时要在 180 的基础上加减！
    block:
        easein_quad 1.5:
            xzoom 1.08
            yzoom 0.92
            rotate 182  # 180 + 2 度
            
        easeout_quad 1.5:
            xzoom 0.92
            yzoom 1.08
            rotate 178  # 180 - 2 度
            
        easein_quad 1.5:
            xzoom 0.95
            yzoom 0.95
            rotate 179  # 180 - 1 度
            
        easeout_quad 1.5:
            xzoom 1.05
            yzoom 1.05
            rotate 181  # 180 + 1 度
            
        repeat



##立绘
image a0:
    "images/fg/fg大崎ベース.webp"
    xpos 940
    ypos 1080
    zoom 1.4
image a:
    "images/fg/fg大崎ベース.webp"
    xpos 540
    ypos 1080
    zoom 1.4
image a1:
    "images/fg/fg大崎ベース1.webp"
    xpos 540
    ypos 1080
    zoom 1.4
image a2:
    "images/fg/fg大崎ベース2.webp"
    xpos 540
    ypos 1080
    zoom 1.4
image a3:
    "images/fg/fg大崎ベース3.webp"
    xpos 540
    ypos 1080
    zoom 1.4
image a4:
    "images/fg/fg大崎ベース4.webp"
    xpos 540
    ypos 1080
    zoom 1.4
image a5:
    "images/fg/fg大崎ベース5.webp"
    xpos 540
    ypos 1080
    zoom 1.4


image b:
    "images/fg/fg静馬ベース.webp"
    xpos 1300
    ypos 1080
    zoom 0.82
image b0:
    "images/fg/fg静馬ベース0.webp"
    xpos 1300
    ypos 1080
    zoom 0.82
image b1:
    "images/fg/fg静馬ベース1.webp"
    xpos 1300
    ypos 1080
    zoom 0.82
image b2:
    "images/fg/fg静馬ベース2.webp"
    xpos 1300
    ypos 1080
    zoom 0.82
image b3:
    "images/fg/fg静馬ベース3.webp"
    xpos 1300
    ypos 1080
    zoom 0.82
image b4:
    "images/fg/fg静馬ベース4.webp"
    xpos 1300
    ypos 1080
    zoom 0.82
image b5:
    "images/fg/fg静馬ベース5.webp"
    xpos 1300
    ypos 1080
    zoom 0.82
image b6:
    "images/fg/fg静馬ベース6.webp"
    xpos 1300
    ypos 1080
    zoom 0.82
image b7:
    "images/fg/fg静馬ベース7.webp"
    xpos 1300
    ypos 1080
    zoom 0.82
image b8:
    "images/fg/fg静馬ベース8.webp"
    xpos 1300
    ypos 1080
    zoom 0.82
image b9:
    "images/fg/fg静馬ベース9.webp"
    xpos 1300
    ypos 1080
    zoom 0.82
image b10:
    "images/fg/fg静馬ベース10.webp"
    xpos 1300
    ypos 1080
    zoom 0.82
image b11:
    "images/fg/fg静馬ベース11.webp"
    xpos 1300
    ypos 1080
    zoom 0.82
image b12:
    "images/fg/fg静馬ベース12.webp"
    xpos 1300
    ypos 1080
    zoom 0.82
image b13:
    "images/fg/fg静馬ベース13.webp"
    xpos 1300
    ypos 1080
    zoom 0.82

image c:
    "images/fg/fg加藤ベース.webp"
    xpos 1300
    ypos 1080
    zoom 1.4
image c0:
    "images/fg/fg加藤ベース.webp"
    xpos 540
    ypos 1080
    zoom 1.4

##背景
image bg0:
    "images/bg/bg0.webp"
    zoom 1.5

image st0:
    "images/st/st0.webp"
    zoom 1.5
image st1:
    "images/st/st1.webp"
    zoom 1.5
image st2:
    "images/st/st2.webp"
    zoom 1.5
image st3:
    "images/st/st3.webp"
    zoom 1.5
image st4:
    "images/st/st4.webp"
    zoom 1.5

##图片
image IMG1:
    "images/st/IMG1.webp"
    zoom 1.5
##开关

init python:
    if not hasattr(persistent, "ending_a"):
        persistent.ending_a = False
    if not hasattr(persistent, "ending_b"):
        persistent.ending_b = False

label start:

    if persistent.ending_a and persistent.ending_b:
        jump chapter4
    jump chapter1

label chapter5:

$ renpy.pause(2, hard=True)

centered "{size=40}对了，{color=#e74c3c}自己{/color}究竟是为了什么原因，才在今天来到轻井泽呢？{/size}"

centered "{size=40}{color=#e74c3c}对自己来说，今天其实是——{/color}{/size}"

menu:
    "从头开始":
        return

# 🎯 1. 定义滚动动画：让整个名单从屏幕下方滑到最上方
transform staff_scroll_action(scroll_time=20.0):
    # 刚开始的时候，把整个名单的顶部顶到屏幕最下方（ypos 1.0），锚点设在上方
    yanchor 0.0
    ypos 1.0
    # 在指定时间内（比如 20 秒），丝滑地匀速向上推到完全出屏（ypos -1.5）
    # 如果你的名单特别长，可以把出屏距离改得更大（比如 -2.5）
    linear scroll_time ypos -2.9

# 🎯 2. 创建一个专属的 Staff 屏幕
# 🎯 修复版：将动画和对齐属性挪到 vbox 身上
screen staff_screen(scroll_time=20.0):
    # 强行反选：在滚字幕时，不让玩家通过点击随意跳过
    #modal True
    
    # 🎯 修正核心：screen 内部直接用 vbox 承载所有属性
    vbox:
        # 1. 让整个滚动动画作用在 vbox 上
        at staff_scroll_action(scroll_time)
        
        # 2. 让 vbox 在屏幕水平居中
        xalign 0.5
        
        # 3. 每一行文字之间的上下间距
        spacing 30 
        
        # ─── 后面所有的文字内容完全不变 ───
        null height 300 
        
        text "【 崎静同人游戏 】" size 24 color "#ff6666" xalign 0.5
        text "完美的一天" size 80 color "#fff" xalign 0.5 bold True
        text "─ 感谢游玩 ─" size 28 color "#ffd700" xalign 0.5
        
        null height 80

        text "【 原 作 】" size 24 color "#ff6666" xalign 0.5
        text "大 秽" size 32 color "#fff" xalign 0.5
        
        null height 80
        
        text "【 剧本 / 企划 】" size 24 color "#ff6666" xalign 0.5
        text "WaterInWater" size 32 color "#fff" xalign 0.5
        
        null height 80
        
        text "【 角色立绘 / CG / UI 】" size 24 color "#ff6666" xalign 0.5
        text "丁丁博士" size 32 color "#fff" xalign 0.5
        
        null height 80

        text "【 背景美术 / 封面设计 / 演出 】" size 24 color "#ff6666" xalign 0.5
        text "WaterInWater" size 32 color "#fff" xalign 0.5

        null height 80
        
        text "【 程序开发 】" size 24 color "#ff6666" xalign 0.5
        text "丁丁博士" size 32 color "#fff" xalign 0.5
        text "WaterInWater" size 32 color "#fff" xalign 0.5
        
        null height 80

        text "【 图片素材 】" size 24 color "#ff6666" xalign 0.5
        text "Unsplash (https://unsplash.com)" size 32 color "#fff" xalign 0.5
        text "Pixabay (https://pixabay.com)" size 32 color "#fff" xalign 0.5
        
        null height 80

        text "【 音乐素材 】" size 24 color "#ff6666" xalign 0.5
        text "Freesound (https://freesound.org)" size 32 color "#fff" xalign 0.5
        text "Pixabay (https://pixabay.com)" size 32 color "#fff" xalign 0.5
        
        null height 80

        text "【 热心测试网友 】" size 24 color "#ff6666" xalign 0.5
        text "皮皮拉鱼 穗一 不知冬" size 32 color "#fff" xalign 0.5

        null height 80
        
        text "【 特别鸣谢 】" size 24 color "#ff6666" xalign 0.5
        text "画了伟大g图的穗一老师" size 32 color "#fff" xalign 0.5

        null height 80
        
        text "【 特别鸣谢 】" size 24 color "#ff6666" xalign 0.5
        text "所有支持本项目的玩家" size 32 color "#fff" xalign 0.5
        
        null height 400
        
        text "THANK YOU FOR PLAYING" size 40 color "#fff" xalign 0.5 bold True

        null height 80

        add "images/nekobox.jpg" xalign 0.5 xsize 100 ysize 100 fit "contain"
        
        null height 400

label endgame:
    # 1. 播放一首适合谢幕的片尾曲（如果是车祸结局，可以切成静音或者风声）
    #play music "audio/music/birthday.ogg"
    
    # 2. 背景切成全黑（或者大崎的遗物、夕阳背影等静态CG）
    scene black with dissolve
    window hide # 隐藏对话框
    
    $ renpy.pause(1.0) # 稍微黑屏安静个 1 秒钟
    
    # 3. 🎯 呼叫 Staff 屏幕！并传入滚动总时间（比如 25.0 秒）
    # 名单越长，这个时间要设置得越长，否则字会飘得像火箭一样快
    show screen staff_screen(scroll_time=40.0)
    
    # 4. 🎯 【极其重要】强行让程序在这里暂停等它滚完！
    # 暂停的时间要和上面滚动的时间完全一致，这样等字幕刚好消失，游戏才会继续往下走
    $ renpy.pause(45.0, hard=True)

    $ renpy.pause(10)
    
    # 5. 滚完之后，安全隐藏掉这个屏幕
    hide screen staff_screen

    scene bg0 with dissolve

    centered "{color=#ffd700}首版发布于\n\n2025.10.10{/color}"

    centered "{color=#ffd700}- 二 〇 二 五 崎 静 生 贺 -{/color}"
    
    # 6. 正式迎来大结局
    
    return # 返回游戏主菜单

# =====================================================================
# 1. 限时选项的倒计时条界面
# =====================================================================
# 参数：
#   time_limit : 总倒计时时间（秒），支持小数，如 5.0
#   timeout_label : 时间到了之后，自动跳转到的 label 名字
screen flash_countdown(time_limit, timeout_label):
    
    default current_time = time_limit

    # 计时器保持不变
    timer 0.05 repeat True action If(current_time > 0, SetScreenVariable("current_time", current_time - 0.05), [Hide("flash_countdown"), Jump(timeout_label)])

    # 使用 Fixed 容器让文字和时间条“重叠”在一起
    fixed:
        xalign 0.5        # 整个组件在屏幕水平居中
        yalign 0.0       # 距离顶部 15% 的高度
        xsize 1920         # 宽度加宽到 700 像素（原本是600）
        ysize 45          # 高度加粗到 45 像素（原本是15，这样文字才塞得下）

        # 1. 底层：时间条
        bar:
            value current_time
            range time_limit
            xsize 1920                 # 宽度与容器一致
            ysize 45                  # 高度与容器一致，变成粗条
            left_bar Frame(Solid("#f4541a"), 0, 0)
            right_bar Frame(Solid("#ba1111"), 0, 0) # 给空条部分加个暗红底色，视觉效果更好

        # 2. 上层：文字（因为在同一个 fixed 里，它会叠在条子正上方）
        text "剩余时间: [current_time:.1f] 秒":
            size 22                   # 字号稍微缩小一点点以适应条子高度
            xalign 0.5                # 水平居中
            yalign 0.5                # 垂直居中（完美呆在条子正中间）
            color "#ffffff"           # 白色字
            outlines [ (1, "#000000", 0, 0) ] # 给文字加1像素黑边，防止进度条扣完变白时看不清字


    

